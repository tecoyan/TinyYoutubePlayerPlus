/******************************************************************************
*TinyYoutubePlayerプラグイン
*tiny_youtube_player_background.js
*処理
*(1)g_nplayer.stopVideo()を監視で起動するため、"stopVideo"メッセージ
*(2)Changeイベントを処理するための監視メッセージ　""
*
******************************************************************************/
console.log("background.jsスタート!!!");
'using strict';

/******************************************************************************
関数 ex_listener(msg, sender, sendResponse)
親タブからのエクステンションのバージョン要求
background.jsはmanifest.jsonファイルからバシージョン取得し、親タブへ応答します。

******************************************************************************/
function ex_listener(msg, sender, sendResponse){
//プレーヤーページからの要求    
    switch(msg.type){
        case "version":
            //
            //manifest.jsonのバージョンをチェック
            const manifest = chrome.runtime.getManifest();
            //ここで、応答を返す
            sendResponse({
                type: 'success',
                version: manifest.version,
                name:manifest.name
            });
            return true;
            break;
        //tabIdを返す
        case "get_tabId":
            console.log("プレーヤーからの、get_tabIdメッセージ受信");
             if(sender.origin.indexOf("tecoyan.net")===-1){
                            return; 
                    }
                    console.log("■get_tabid　msg.subdomain = "+msg.subdomain);
                    subdomain = msg.subdomain;
                    tabs_id_player=[]; tabs_id_youtube=[];tabs_id_other=[];
                    //tabs.queryで、プレーヤーを見つける
                    chrome.tabs.query({}, tabs => {
                            ttabs = tabs;
                            //parent_urlのタブid(active_tab_id)をチェック
                            for(let i=0; i<tabs.length; i++){
                                
                                    try{
                                        //**********************************************************
                                        //プレーヤータブ　                    
                                        //**********************************************************
                                        //ここで、プレーヤータブがあるかをチェック
                                        if(tabs[i].url.indexOf("https://") !== -1){
                                                 tabs_id_player.push(tabs[i].id);
                                                 opener = tabs[i].id;
                                                 console.log("関数 check_player_tab_exist() 変数 tabs_id_player "+tabs[i].id);
                                         }
                                         break;
                                    }catch(e){
                                        continue;

                                    }
                            }
                            //このタイミングで、tabs_id_playerがないケースあり?
                            //空の配列で初期値がない。
                            console.log("●●●配列は空かtabs_id_player　"+tabs_id_player);
                            if(tabs_id_player.length===0){
                                console.log("●●●配列は空");
                                return; 
                            }
                            //
                            player_id = tabs_id_player.reduce(aryMin); //
                            opener = player_id;
                            sendResponse({opener:opener});
                    });
            break;            
        //プレーヤータブのindex.jsからリクエストを受信
        case "get_vid_list":
            //
            sendResponse({'vid_list':vid_list});
            
            
            
            break;
     }

}
/******************************************************************************
//External(Webアプリ)からバージョンリクエスト受信待ち
******************************************************************************/
chrome.runtime.onMessageExternal.addListener(ex_listener);

let sts;let message;
/****************************************************************
 * menu.html タブを生成
 *****************************************************************/
console.log("■■background.jsスタート");
///****************************************************************************
//*リスナー メッセージを受信する　tabは複数ありえる
//■(1)stop_videoメッセージ()
//■**************************************************************************/
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    console.log("slim_content.jsから受信 送信元情報 "+sender.origin);
    console.log("slim_content.jsから受信 msg.data " +msg.data);
    //メッセージをチェック
    switch(msg.data){
        /***************************************************************
         * 全タブのframeプレーヤーで再生する監視を起動
         * 
         ****************************************************************/
        case "stop_video":
                    let tabId;
                    const sleep = (s) => new Promise(f => setTimeout(f, s * 1000));
                    async function async_Loop(){      
                                //全タブのframeプレーヤーで再生する監視を起動
                                //tabs.query() Webnavigation
                                chrome.tabs.query({}, (tabs) => {

                                        const tab_arr = Object.values(tabs);
                                        (async ()=>{
                                                for await (const tab of tab_arr) {
                                                    console.log("for await ループ　"+tab.id);
                                                    tabId = tab.id;
                                                    try{
                                                            //urlをチェック                    
                                                            if (tab.url.indexOf("https://") !== -1) {
                                                                    //ここで、タブの全フレームデータを取得して保存
                                                                    chrome.webNavigation.getAllFrames({tabId: tabId,}).then(logFrameInfo, onError);
                                                                    console.log("■　■　■getAllFrames()コール後　"+tabId);
                                                                    await sleep(0.5);
                                                            }else{

                                                            }

                                                    }catch(e){
                                                            //なし
                                                    }
                                                }
                                    })();
                                        /*
                                         *すべてのフレームの中から、プレーヤーフレームを検索して出力
                                         * 
                                         */
                                        function logFrameInfo(framesInfo) {
                        console.log("■　■　■　logFrameInfo　" + framesInfo.length);
                        const frm_arr = Object.values(framesInfo);
                        (async () => {
                            for await (const frm of frm_arr) {
                                try {
                                    //iframeプレーヤーチェック
                                    if (frm.url.indexOf("https://favorite.tecoyan.net") !== -1) {
                                        console.log("●✖▼■フレームInfo url = " + frm.url + "  " + tabId);
                                        //executeScript()を実行
                                        //filesとfuncを同時に指定できないので分けて出す。
                                        chrome.scripting.executeScript({
                                            target: {tabId: tabId, frameIds: [frm.frameId]},
                                            files: ["jquery.js"]
                                        }).then(() => {
                                            //ここでもexecuteScript()を出す
                                            chrome.scripting.executeScript({
                                                //ターゲットのフレームIdのDOMへアクセス  
                                                target: {tabId: tabId, frameIds: [frm.frameId]},
                                                //実行コード
                                                func: () => {
                                                    //$を使うには、先にfiles:指定しておく。
                                                    //これでDOMにアクセス可能
                                                    $('#observ1').attr('title', 'test');        //属性を変更して監視を起動
                                                    //observ1の監視でg_nplayer.stopVideo()を実行
                                                    $("ul").css("background-color", "lightgrey");
                                                    console.log("executeScript console.logテスト");
                                                }
                                            });
                                        });
                                        await sleep(0.5);

                                    }
                                    else {

                                    }
                                }
                                catch (e) {

                                }
                            }
                        })();
                    }
                                          //
                                          function onError(error) {
                                            console.error(`Error: ${error}`);
                                          }

                            });
                    }
                    (async ()=>{
                            async_Loop(); 
                
                    }).call();
                    
                    break; 
        
                
    }
    return false;
});
