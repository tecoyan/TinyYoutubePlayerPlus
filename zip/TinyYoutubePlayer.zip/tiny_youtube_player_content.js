/******************************************************************************
*表題：　　　　　TinyYoutubePlayerプラグイン
*要件：           拡張機能は、目的が明確で理解しやすい単一の目的とする。
*プラグイン：   このプラグインは、すべてのタブで動作する小型のyoutubeプレーヤーです。
*                   その他の機能は削除
*                   iframeでサイトのurlをロードし再生します。
*                   url=https://favorite.tecoyan.net/slim/index_radio_simple.php
*このドメインであれば、すべてのWebサイトのタブで動作します。same origin制約で許可されています。                   
*
*ファイル名：   tiny_youtube_player_content.js
*説明：           すべてのタブで動作するcontent.jsファイルです。このスクリプトでbody要素に
*                   iframeプレーヤーをアペンドします。
*                   検索結果を保存します。
*                   リストキーと本体データ(サムネイルとタイトルの配列)
*                   あらかじめ、jquery.jsをロードしています。
*ロード元:      C:\拡張プラグイン\TinyYoutubePlayer
******************************************************************************/
//このファイルで使用している変数のみにする
//let yahoo_search;
let params;
let tab_sw;
let p_element;
//let subdomain;                  //
//グローバルオブジェクト変数
let other;
//
other = {

//
    main: function () {
            /********************************************************************************
             *iframeのsrcに指定しているURLのphpファイルでheader("Access-Control-Allow-Origin: *");を
             *指定しているため、このhtmlページはすべてのサイトで動作可能
             *
             *********************************************************************************/
            //プレーヤー要素の追加
            //alert("youtube_radio要素をアペンドします。");
            let html ="<!-- youtubeラジオ　-->\n\
<div id='youtube_radio' title='ここでclickするとプラグインの説明を表示します。' style='background-color:lightyellow;z-index:999999;border: 10px solid lawngreen; width: 170px;height: 265px; position: fixed;zoom: 1.5;top:42px;right:0px;zoom:1.5;'>\n\
<img style='zoom:0.5;' src='https://favorite.tecoyan.net/slim/images/radio_small.png'><span  style='zoom:0.9;position:absolute;top:0px;right:10px;font-size:10px;'>TinyYoutubePlayerプラグインv1.0</span>\n\
<iframe class='iframe_radio' style='position:relative;top:0px;border:solid 2px orange; width:150px;height:220px;' src='https://favorite.tecoyan.net/slim/index_radio_simple.php?vid=YNQT68uHpyg&title=%E4%BB%8A%E6%97%A5%E3%81%AE%E6%97%A5%E3%81%AF%E3%81%95%E3%82%88%E3%81%86%E3%81%AA%E3%82%89%E3%80%80%E6%A3%AE%E5%B1%B1%E8%89%AF%E5%AD%90%E3%80%801967&url=&db_id=3120'></iframe>\n\
</div>";
            

            $("body").append(html);
            $("#youtube_radio").css("display","none");
            //alert("other.main()コール");
            //$("#youtube_radio").draggable();
            //
             document.getElementById("youtube_radio").onpointermove = function(event){
                      if(event.buttons){
                          this.style.left     = this.offsetLeft + event.movementX + 'px';
                          this.style.top      = this.offsetTop  + event.movementY + 'px';
                          this.style.position = 'absolute';
                          this.draggable      = false;
                          this.setPointerCapture(event.pointerId);
                      }
                      //
                      $("#youtube_radio").css("position","fixed");

              };
    }
};
/************************************************************************
*確認メッセージ 
* 
************************************************************************/
$("body").on('click',(e)=>{
    if(e.ctrlKey===true){

        if(window.confirm("youtubeプレーヤで再生しますか?")){
             //alert("プレーヤーを開きます。");
             //ラジオプラグインを利用
             $("#youtube_radio").css("display","block");

        }else{// 「キャンセル」時の処理開始
            $("#youtube_radio").css("display","none");
            //ここで再生を停止
            //プラグインからiframeのプレーヤーへ再生停止要求を出すには。
            //テスト的に"stop_video"メッセージをbackground.jsへ出す
            chrome.runtime.sendMessage({data: 'stop_video'}, function (msg) {
                       //応答は? 特になし。     
                            
            });
            return;
        }  
    }else{
        //
        if(e.target.id==='youtube_radio'){
                    alert("プラグインの説明\n\
このプラグインはTinyYoutubePlayerプラグインです。\n\
リストのサムネイルをクリックすると再生します。\n\
リストはランダムで連続自動再生します。\n\
\n\
このiframeプレーヤーはすべてのwebページで再生します。\n\
");
                    return false;
        }
        
        
        
    }
    
});
//
tab_sw = tab_case();
/********************************************************************************
*タブ処理へ分岐  
*                   slim_content.jsは、タブ毎に処理空間を持つ
*                   タブ毎の処理を分岐　タブ毎にオブジェクト定義　その中のmain()メソッドをコールしている
*                   tab_swで分岐
*                   ここで、#temp_pluginをチェックして、オンオフにより、
********************************************************************************/
switch (tab_sw) {
    case "other":
            other.main();     
            break;
}
//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
//共通関数
//確認ダイヤログ
//■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
function confirm_dialog(mess) {
    params = {
        mess: mess
    };
    var resp = $.ajax({
        url: 'https://common.tecoyan.net/plugin/slim/popup_dialog.php',
        type: 'POST',
        dataType: 'html',
        cache: false,
        data: params,
        async: false
    }).responseText;
    $("#popup_panel").html(resp);

}
//******************************************************************************
//スイッチ変数
//タブ処理分岐
//******************************************************************************
function tab_case() {

           //その他
           return "other";
}